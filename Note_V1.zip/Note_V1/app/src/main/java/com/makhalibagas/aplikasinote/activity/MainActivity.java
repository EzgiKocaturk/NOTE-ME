package com.makhalibagas.aplikasinote.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.SearchView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.makhalibagas.aplikasinote.R;
import com.makhalibagas.aplikasinote.adapter.NoteAdapter;
import com.makhalibagas.aplikasinote.database.NoteDatabase;
import com.makhalibagas.aplikasinote.entities.Note;
import com.makhalibagas.aplikasinote.utils.onClickItem;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements onClickItem {

    private RecyclerView recyclerView;
    private List<Note> noteList;
    private NoteAdapter noteAdapter;

    public static final int REQUEST_ADD = 1;
    public static final int REQUEST_UPDATE = 2;
    public static final int REQUEST_SHOW = 3;

    private int onClickPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButtonCreateNote);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(getApplicationContext(), CreateNoteActivity.class), REQUEST_ADD);
            }
        });

        recyclerView = findViewById(R.id.rv);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
        noteList = new ArrayList<>();
        noteAdapter = new NoteAdapter(noteList, this);
        recyclerView.setAdapter(noteAdapter);

        getNote(REQUEST_SHOW, false);

        SearchView searchView = findViewById(R.id.searcviewCatatan);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                noteAdapter.getFilter().filter(query);

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                noteAdapter.getFilter().filter(newText);

                return false;
            }
        });
    }


    private void getNote(final int requestCode, final boolean deleteNote){


        @SuppressLint("StaticFieldLeak")
        class GetNoteAsyncTask extends AsyncTask<Void, Void, List<Note>>{

            @Override
            protected List<Note> doInBackground(Void... voids) {
                return NoteDatabase.getInstance(getApplicationContext()).noteDao().getAllNote();
            }

            @Override
            protected void onPostExecute(List<Note> notes) {
                super.onPostExecute(notes);
                if (requestCode == REQUEST_SHOW){
                    noteList.addAll(notes);
                    noteAdapter.notifyDataSetChanged();
                }else if (requestCode == REQUEST_ADD){
                    noteList.add(0 , notes.get(0));
                    noteAdapter.notifyItemInserted(0);
                    recyclerView.smoothScrollToPosition(0);
                }else if (requestCode == REQUEST_UPDATE){
                    noteList.remove(onClickPosition);
                    if (deleteNote){
                        noteAdapter.notifyItemRemoved(onClickPosition);
                    }else {
                        noteList.add(onClickPosition, notes.get(onClickPosition));
                        noteAdapter.notifyItemChanged(onClickPosition);
                    }
                }
            }
        }

        new GetNoteAsyncTask().execute();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ADD && resultCode == RESULT_OK ){
            getNote(REQUEST_ADD, false);
        }else if (requestCode == REQUEST_UPDATE && resultCode == RESULT_OK){
            if (data != null){
                getNote(REQUEST_UPDATE, data.getBooleanExtra("NoteDelete", false));
            }
        }
    }

    @Override
    public void onClick(Note note, int position) {
        onClickPosition = position;
        Intent intent = new Intent(getApplicationContext(), CreateNoteActivity.class);
        intent.putExtra("EXTRA", true);
        intent.putExtra("EXTRA_NOTE", note);
        startActivityForResult(intent, REQUEST_UPDATE);
    }
}
