package com.makhalibagas.aplikasinote.utils;

import com.makhalibagas.aplikasinote.entities.Note;

/**
 * Created by Bagas Makhali on 6/19/2020.
 */
public interface onClickItem {

    void onClick(Note note, int position);
}
